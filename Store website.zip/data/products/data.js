const products = [
    { id: 1, name: "Men's T-Shirt", price: 20, image: "images/shirt.jpg" },
    { id: 2, name: "Women's Dress", price: 35, image: "images/dress.jpg" },
    { id: 3, name: "Men's Jacket", price: 50, image: "images/jacket.jpg" },
    { id: 4, name: "Women's Shoes", price: 40, image: "images/shoes.jpg" },
    { id: 5, name: "Kids Hoodie", price: 30, image: "images/kidshoodie.jpg" },
    { id: 6, name: "Men's Watch", price: 100, image: "images/watch.jpg" },
    { id: 7, name: "Women's Purse", price: 45, image: "images/purse.jpg" },
    { id: 8, name: "Men's Sneakers", price: 55, image: "images/sneakers.jpg" },
    { id: 9, name: "Women's Jeans", price: 60, image: "images/jeans.jpg" },
    { id: 10, name: "Kid's T-Shirt", price: 15, image: "images/kidstshirt.jpg" }
];

// Generate 100 products (Repeat the first 10 products 10 times)
const fullProductList = [];
for (let i = 0; i < 10; i++) {
    products.forEach((product) => {
        fullProductList.push({ ...product, id: fullProductList.length + 1 });
    });
}
